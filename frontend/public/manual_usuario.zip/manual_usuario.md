# Manual de Usuario Completo - ConfirmingAPP

Bienvenido al manual oficial de **ConfirmingAPP**. Esta guía le acompañará paso a paso en el uso de la aplicación para la gestión eficiente de remesas bancarias.

## Índice
1.  [Panel de Control (Dashboard)](#1-panel-de-control-dashboard)
2.  [Gestión de Remesas](#2-gestión-de-remesas-flujo-principal)
3.  [Histórico y Exportación](#3-histórico-y-exportación)
4.  [Base de Datos de Proveedores](#4-base-de-datos-de-proveedores)
5.  [Configuración del Sistema](#5-configuración-del-sistema)

---

## 1. Panel de Control (Dashboard)
Al acceder a la aplicación, aterrizará en el Dashboard. Este panel está diseñado para ofrecerle una visión global del estado de su tesorería en tiempo real.

````carousel
![Visión Global](images/dashboard_real_1766143949434.png)
````

### Elementos Clave
-   **Tarjetas KPI**:
    -   *Total Facturas*: Número acumulado de facturas procesadas históricamente.
    -   *Volumen Total*: Suma en euros de todas las remesas gestionadas.
    -   *Remesas Generadas*: Contador de archivos creados.
-   **Gráfico de Tendencias**: Visualización mensual del volumen de pagos, ideal para detectar picos estacionales de tesorería.
-   **Actividad Reciente**: Listado cronológico de las últimas acciones (subidas, descargas, borrados), útil para auditoría rápida.

---

## 2. Gestión de Remesas (Flujo Principal)
El corazón de la aplicación. Aquí transformará sus hojas de Excel desordenadas en archivos bancarios estandarizados (Norma Bankinter).

### Paso 1: Carga de Datos
Navegue a la sección **"Nueva Remesa"** en el menú lateral.

````carousel
![Área de Carga](images/upload_real_1766144051928.png)
````
-   **Arrastrar y Soltar**: Puede arrastrar su archivo Excel directamente al recuadro central.
-   **Formatos Soportados**: `.xlsx` y `.xls`.
-   **Detección de Duplicados**: Si intenta subir un archivo que ya ha sido procesado (basado en su contenido exacto), el sistema le avisará para prevenir errores de doble pago.

### Paso 2: Validación Inteligente
Una vez cargado el archivo, ConfirmingAPP analiza cada línea.

````carousel
![Revisión de Facturas](images/upload_review_real_1766144099310.png)
````

-   **Semáforos de Estado**:
    -   🟢 **OK**: La factura tiene todos los datos necesarios (CIF, Nombre, IBAN, Importe).
    -   🔴 **Error Crítico**: Falta el IBAN o el CIF no es válido. Estas facturas bloquearán la remesa hasta ser corregidas.
    -   🟠 **Aviso**: Discrepancias menores (ej. un proveedor con múltiples cuentas posibles).
-   **Corrección en Línea**: No necesita volver al Excel. Pulse el icono del **Lápiz** en cualquier fila problemática para añadir el IBAN faltante o corregir un nombre. Los cambios se guardarán en la "Base de Datos de Proveedores" para futuras ocasiones.

### Paso 3: Confirmación
Antes de finalizar, revise la **Barra de Resumen** situada al final de la tabla.
-   Verifique el **Número de Facturas** y, lo más importante, el **Importe Total** de la remesa.
-   Pulse **"Confirmar Lote"** para generar el archivo definitivo.

---

## 3. Histórico y Exportación
Acceda al menú **"Histórico"** para consultar su archivo digital.

````carousel
![Histórico de Lotes](images/history_real_1766144004279.png)
````

### Acciones Disponibles
1.  **Descargar (⬇️)**: Genera el archivo final para subir a la web del banco.
    -   *Nota*: Si ha configurado una "Carpeta de Copia Local" en Ajustes, una copia se guardará automáticamente en su servidor por seguridad.
2.  **Eliminar (🗑️)**: Permite borrar una remesa errónea. Requiere confirmación explícita para evitar accidentes.
3.  **Logs de Importación**: En la pestaña superior "Logs", puede ver un registro técnico de cada intento de subida, útil para diagnosticar problemas con archivos rechazados.

---

## 4. Base de Datos de Proveedores
En la sección **"Proveedores"**, la aplicación acumula la inteligencia de su negocio.

````carousel
![Gestión de Proveedores](images/providers_real_1766144020329.png)
````

-   **Aprendizaje Automático**: Cada vez que sube una remesa o corrige un dato manualmente, esta base de datos se actualiza.
-   **Búsqueda Rápida**: Utilice la barra superior para encontrar proveedores por Nombre o CIF.
-   **Gestión Manual**: Puede añadir proveedores manualmente o editar sus IBANs y plazos de pago predeterminados. Esto asegura que, en futuras importaciones, el sistema "rellene" automáticamente los datos faltantes del Excel.

---

## 5. Configuración del Sistema
Personalice la aplicación a su medida en **"Ajustes"** (⚙️).

````carousel
![Panel de Ajustes](images/settings_real_1766144034911.png)
````

-   **Datos de Empresa**: Configure aquí su Nombre, CIF y, crucialmente, el **Sufijo** y **Cuenta de Cargo** que exige Bankinter para procesar los archivos.
-   **Carpeta de Copia Local**: Defina una ruta absoluta (ej: `Z:\Contabilidad\Remesas`) donde quiera que se guarden copias de seguridad de los archivos generados.
-   **Apariencia**: Cambie entre el Modo Claro y el **Modo Oscuro** (Dark Mode) según su preferencia visual o condiciones de luz.
